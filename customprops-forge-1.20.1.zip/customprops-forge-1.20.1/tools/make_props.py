#!/usr/bin/env python3
"""Generates placeable block models (scaled/flattened OBJ copies) and the
split banknote item models. Run from the project root:  python3 tools/make_props.py
"""
import json, os, re

BASE = "src/main/resources/assets/customprops"
ITEM = f"{BASE}/models/item"
BLOCK = f"{BASE}/models/block"

# --- placeable food props: block size (1.0 = full block) ---
FOOD_SCALE = {"papas": 0.40, "ayran": 0.40, "nuggets": 0.35, "cajita": 0.45}

# --- banknotes, in the order they appear (top to bottom) in turk_lirasi_t0.png ---
NOTES = [20, 50, 100, 200]


def read_obj(path):
    return open(path, encoding="utf-8").read().splitlines()


def fmt(*a):
    return " ".join(f"{x:.5f}" for x in a)


def scale_food(name, s):
    lines = read_obj(f"{ITEM}/{name}.obj")
    ys = [float(l.split()[2]) for l in lines if l.startswith("v ")]
    ymin = min(ys)
    out = []
    for l in lines:
        if l.startswith("v "):
            x, y, z = map(float, l.split()[1:4])
            out.append("v " + fmt(0.5 + (x - 0.5) * s, (y - ymin) * s, 0.5 + (z - 0.5) * s))
        else:
            out.append(l)
    open(f"{BLOCK}/{name}.obj", "w", encoding="utf-8").write("\n".join(out) + "\n")
    mtl = f"{ITEM}/{name}.mtl"
    open(f"{BLOCK}/{name}.mtl", "w").write(open(mtl).read())


def split_notes():
    lines = read_obj(f"{ITEM}/turk_lirasi.obj")
    v = [l for l in lines if l.startswith("v ")]
    vt = [l for l in lines if l.startswith("vt ")]
    vn = [l for l in lines if l.startswith("vn ")]
    f = [l for l in lines if l.startswith("f ")]
    per_v = len(v) // len(NOTES)   # 24 vertices per note
    per_f = len(f) // len(NOTES)   # 12 triangles per note
    assert per_v * len(NOTES) == len(v) and per_f * len(NOTES) == len(f)
    for k, val in enumerate(NOTES):
        vs = [list(map(float, l.split()[1:4])) for l in v[k*per_v:(k+1)*per_v]]
        ts = vt[k*per_v:(k+1)*per_v]
        ns = [list(map(float, l.split()[1:4])) for l in vn[k*per_v:(k+1)*per_v]]
        cy = (min(p[1] for p in vs) + max(p[1] for p in vs)) / 2
        fs = []
        for l in f[k*per_f:(k+1)*per_f]:
            parts = []
            for tok in l.split()[1:]:
                a, b, c = (int(i) - k*per_v for i in tok.split("/"))
                parts.append(f"{a}/{b}/{c}")
            fs.append("f " + " ".join(parts))
        name = f"turk_lirasi_{val}"

        # item model: same standing pose, but centred vertically so it sits in the hand/GUI
        item = ["# " + name, "mtllib turk_lirasi.mtl", f"g {name}_m0", "usemtl m0"]
        item += ["v " + fmt(p[0], p[1] - cy + 0.5, p[2]) for p in vs]
        item += list(ts) + ["vn " + fmt(*n) for n in ns] + fs
        open(f"{ITEM}/{name}.obj", "w").write("\n".join(item) + "\n")

        # block model: rotated to lie flat on the floor (proper rotation: (x,y,z)->(x,z,-y))
        blk = ["# " + name, "mtllib turk_lirasi.mtl", f"g {name}_m0", "usemtl m0"]
        blk += ["v " + fmt(p[0], (p[2] - 0.5) + 0.002, 0.5 - (p[1] - cy)) for p in vs]
        blk += list(ts) + ["vn " + fmt(n[0], n[2], -n[1]) for n in ns] + fs
        open(f"{BLOCK}/{name}.obj", "w").write("\n".join(item[:0] + blk) + "\n")

        # item json = old json with new model path
        j = json.load(open(f"{ITEM}/turk_lirasi.json"))
        j["model"] = f"customprops:models/item/{name}.obj"
        j["textures"]["particle"] = "customprops:item/turk_lirasi_t0"
        json.dump(j, open(f"{ITEM}/{name}.json", "w"), indent=2)
    open(f"{BLOCK}/turk_lirasi.mtl", "w").write(open(f"{ITEM}/turk_lirasi.mtl").read())


def block_assets(name, particle):
    json.dump({"loader": "forge:obj", "model": f"customprops:models/block/{name}.obj",
               "flip_v": True, "automatic_culling": False, "render_type": "minecraft:cutout",
               "textures": {"particle": particle}},
              open(f"{BLOCK}/{name}.json", "w"), indent=2)
    json.dump({"variants": {f"facing={d}": ({"model": f"customprops:block/{name}"} | ({"y": y} if y else {}))
                            for d, y in [("north", 0), ("east", 90), ("south", 180), ("west", 270)]}},
              open(f"{BASE}/blockstates/{name}.json", "w"), indent=2)
    loot = f"src/main/resources/data/customprops/loot_tables/blocks/{name}.json"
    json.dump({"type": "minecraft:block", "pools": [{"rolls": 1,
               "entries": [{"type": "minecraft:item", "name": f"customprops:{name}"}],
               "conditions": [{"condition": "minecraft:survives_explosion"}]}]},
              open(loot, "w"), indent=2)


if __name__ == "__main__":
    for n, s in FOOD_SCALE.items():
        scale_food(n, s)
        block_assets(n, f"customprops:item/{n}_palette" if n != "ayran" and n != "nuggets" else
                     ("customprops:item/ayran_t0" if n == "ayran" else "customprops:item/nuggets_palette"))
    split_notes()
    for val in NOTES:
        block_assets(f"turk_lirasi_{val}", "customprops:item/turk_lirasi_t0")
    print("done")
