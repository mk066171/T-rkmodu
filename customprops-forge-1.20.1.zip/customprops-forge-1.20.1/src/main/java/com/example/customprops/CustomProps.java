package com.example.customprops;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(CustomProps.MODID)
public class CustomProps {
    public static final String MODID = "customprops";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    /** Hand-held only items. */
    private static final String[] PROP_NAMES = {
        "awm",
        "cigar",
        "refresco",
        "galaxy_s25_ultra",
        "galaxy_s24_ultra",
        "money_gun",
        "vape_pen",
        "redmi_12",
        "zippo_lighter"
    };

    /** Items that can also be placed in the world as small blocks (name, width px, height px). */
    private static final Object[][] PLACEABLE = {
        { "papas",   6, 8 },
        { "ayran",   6, 8 },
        { "nuggets", 6, 3 },
        { "cajita",  7, 7 },
    };

    /** Banknotes: separate item + flat placeable block for each denomination. */
    private static final int[] NOTES = { 20, 50, 100, 200 };

    public static final List<RegistryObject<Item>> PROPS = new ArrayList<>();

    public static final RegistryObject<Block> BRICK_OVEN = BLOCKS.register("brick_oven",
            () -> new BrickOvenBlock(BlockBehaviour.Properties.of().strength(2.0f).noOcclusion()));
    public static final RegistryObject<Item> BRICK_OVEN_ITEM = ITEMS.register("brick_oven",
            () -> new BlockItem(BRICK_OVEN.get(), new Item.Properties()));

    private static void registerPlaceable(String name, VoxelShape ns, VoxelShape ew) {
        RegistryObject<Block> block = BLOCKS.register(name, () -> new PropBlock(
                BlockBehaviour.Properties.of().strength(0.3f).noOcclusion().sound(SoundType.WOOL), ns, ew));
        PROPS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties().stacksTo(16))));
    }

    static {
        for (String n : PROP_NAMES) {
            PROPS.add(ITEMS.register(n, () -> new Item(new Item.Properties().stacksTo(16))));
        }
        for (Object[] p : PLACEABLE) {
            int w = (Integer) p[1], h = (Integer) p[2];
            VoxelShape box = Block.box(8 - w / 2.0, 0, 8 - w / 2.0, 8 + w / 2.0, h, 8 + w / 2.0);
            registerPlaceable((String) p[0], box, box);
        }
        for (int v : NOTES) {
            VoxelShape ns = Block.box(2.9, 0, 6.1, 13.1, 0.5, 9.9);   // flat on the floor
            VoxelShape ew = Block.box(6.1, 0, 2.9, 9.9, 0.5, 13.1);
            registerPlaceable("turk_lirasi_" + v, ns, ew);
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("props", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> new ItemStack(PROPS.get(PROPS.size() - 1).get()))
                    .displayItems((params, output) -> {
                        output.accept(BRICK_OVEN_ITEM.get());
                        for (RegistryObject<Item> i : PROPS) output.accept(i.get());
                    })
                    .build());

    public CustomProps() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
